package com.example.lab01.myapp

fun main()
{
    println("xin chao tat ca")
    println("hom nay troi nhe len cao")
    println("toi buon khong hieu vi sao toi buon")
    println("Trời hôm nay đẹp quá")
    var a : Long = 100L
    println("so a la" + a)
    fun prinhello()
    {
        println("day la ham hien thi hello")
    }

    prinhello()


}