package com.example.lab01.myapp

fun main(){
    val numberOfStudents = 50
    if (numberOfStudents in 1..100) {
        println(numberOfStudents)
    }

}